pkg install nodejs -y
pkg install ffmpeg -y
pkg install imagemagick -y
npm install
npm audit fix

echo "SUDAH SELESAI TINGGAL node index.js SOB:)"
echo "JANGAN LUPA SU[!]BREK CHANNEL A PROJECT NEW UPDATE:)"
echo "[!] Bila terjadi error hapus folder node_modules lalu ketik npm i enter npm audit fix enter DONE:)"
