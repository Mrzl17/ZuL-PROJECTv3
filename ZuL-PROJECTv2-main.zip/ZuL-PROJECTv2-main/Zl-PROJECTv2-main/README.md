<p align="center">
<img src="tmp/A-PROJECT.jpg" width="250" height="250"/>
</p>
<p align="center">
<a href="#"><img title="Whatsapp-Bot" src="https://img.shields.io/badge/Bot Termux A PROJECTv2-red?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>

### INSTALL COMMAND
CEK YUTUB https://youtu.be/dAbXAqfJpdg

## PREFIX
```bash
/!#$%?\~.
```

# Fitur

| A |               LIST Fitur           |
| :-----------: | :--------------------------------: |
|       ✅       | MAKER          |
|       ✅       | RANDOM                    |
|       ✅       | GABUTz             |
|       ✅       | OTHER   |
|       ✅       | DOWNLOAD |
|       ✅       | EXP & LIMIT |
|       ✅       | GROUP |
|       ✅       | JADI BOT |
|       ✅       | OWNER |

## SPECIAL THANKS TO

# AUTHOR SC
* <a href="https://github.com/Nurutomo/wabot-aq"><img alt="GitHub" src="https://img.shields.io/badge/NURUTOMO%20-%23121011.svg?&style=for-the-badge&logo=github&logoColor=white"/></a>

# APIKEY
* [![API ZEKS](https://img.shields.io/badge/ZEKS-3b5998?style=flat-square&logo=ardi&logoColor=white)](https://api.zeks.xyz)
* [![VIDEFIKRI](https://img.shields.io/badge/VIDEFIKRI-3b5998?style=flat-square&logo=ardi&logoColor=white)](https://videfikri.com)
* [![ZEKAIS](https://img.shields.io/badge/ZEKAIS-3b5998?style=flat-square&logo=ardi&logoColor=white)](https://zekais-api.herokuapp.com)
* [![ONLY DEV CITY](https://img.shields.io/badge/ONLYDEVCITY-3b5998?style=flat-square&logo=ardi&logoColor=white)](https://onlydevcity.herokuapp.com)
* [![TOBZ](https://img.shields.io/badge/TOBZ-3b5998?style=flat-square&logo=ardi&logoColor=white)](https://tobz-api.herokuapp.com)
